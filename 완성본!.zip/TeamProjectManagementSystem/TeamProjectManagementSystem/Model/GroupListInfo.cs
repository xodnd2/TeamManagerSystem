﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamProjectManagementSystem.Model
{
    public class GroupListInfo // 팀 목록 불러올 때
    {
        public string team_Name { get; set; }
    }
}
    