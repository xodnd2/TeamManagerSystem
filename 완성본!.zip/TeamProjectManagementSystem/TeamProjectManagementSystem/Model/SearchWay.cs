﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamProjectManagementSystem.Model
{
    class SearchWay
    {
        public string way { get; set; }

        public SearchWay(string way_)
        {
            way = way_;
        }
    }
}
