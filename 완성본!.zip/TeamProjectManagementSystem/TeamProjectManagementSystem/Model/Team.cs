﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeamProjectManagementSystem.Model
{
    class Team // 팀 만들 때
    {
        public string name { get; set; }
        public string intro { get; set; }
    }
}
